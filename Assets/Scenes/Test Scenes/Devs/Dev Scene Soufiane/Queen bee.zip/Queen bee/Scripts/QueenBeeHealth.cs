using System.Collections;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class QueenBeeHealth : MonoBehaviour
{}